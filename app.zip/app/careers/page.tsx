import type { Metadata } from "next";
import CareersHero from "../components/careers-components/careershero";
import PathSection from "../components/careers-components/Pathsection";
import CareersClient from "../components/careers-components/jobs";

// ============================================
// SEO VARIABLES - UPDATE ONLY THESE VALUES
// ============================================
// Variable 1: Page Title (Used for regular SEO, OG, and Twitter)
const PAGE_TITLE = "Embark on Your Career Journey | Join AdRefresh";

// Variable 2: Meta Description (Used for regular SEO, OG, and Twitter)
const PAGE_DESCRIPTION = "Learn, grow, and build your career with us. Work with global brands, fast-paced teams, and growth-focused opportunities.";

// Variable 3: Canonical URL
const SEO_CANONICAL_URL = "https://www.adrefresh.com/careers";

// Variable 4: Open Graph Image URL (Optional - only modify if you need a custom image)
const SEO_OG_IMAGE_URL = "https://www.adrefresh.com/og/careers.png";

// ============================================
// METADATA GENERATION - DO NOT MODIFY BELOW
// ============================================

export const metadata: Metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,

  alternates: {
    canonical: SEO_CANONICAL_URL,
  },

  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: SEO_CANONICAL_URL,
    siteName: "AdRefresh", // Hardcoded - no variable
    images: [
      {
        url: SEO_OG_IMAGE_URL,
        width: 1200,
        height: 630,
        alt: "Careers at AdRefresh", // Hardcoded - no variable
      },
    ],
    locale: "en_US",
    type: "website",
  },

  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    images: [SEO_OG_IMAGE_URL],
  },

  robots: {
    index: true,
    follow: true,
  },
};

export default function CareersPage() {
  return (
    <main className="bg-[#fafafa] text-[#111] careers-manrope">
      <CareersHero />
      <PathSection />
      <CareersClient />
    </main>
  );
}

